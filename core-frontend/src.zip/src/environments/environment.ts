// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: true,
  // production: false,
  apiBaseURL: 'https://witch-hunting.com',
  // apiBaseURL: 'http://192.168.0.4:8080',
};